#include<string.h>
#include<fcntl.h>
#include<stdlib.h>
#include<stdio.h>
#include <unistd.h>
void input();
void search(char *);
void suggest(char *);

int main(int argc, char *argv[]) {
	if(argc == 2){
		if(strcmp(argv[1], "-h") == 0){
			printf("1.Enter the word you want to search in the dictionary and press enter\n2.Press Cntl + D to stop the program execution.");		
		}	
	}
 	input();
	return 0;
}

void input(){
	printf("Enter the word you want search in dictionary\n");
	int len, fd, i;
	char s[60];
	while((scanf("%s", s)) != -1){
		len = strlen(s);
		for(i = 0; i < len; i++){
			switch(s[i]){
				case 'A':
					 s[i] = 'a';
					 break;
				case 'B':
					 s[i] = 'b';
					 break;
				case 'C':
					 s[i] = 'c';
					 break;
				case 'D':
					 s[i] = 'd'; 
					 break;
				case 'E':
					 s[i] = 'e';
					 break;
				case 'F':
					 s[i] = 'f';
					 break;
				case 'G':
					 s[i] = 'g';
					 break;
				case 'H':
					 s[i] = 'h';
				         break;
				case 'I': 
					 s[i] = 'i'; 
					 break;
				case 'J': 
					 s[i] = 'j'; 
					 break;
				case 'K':
					 s[i] = 'k';
					 break;
				case 'L': 	
					 s[i] = 'l';
					 break;
				case 'M':
					 s[i] = 'm';
					 break;
				case 'N':
					 s[i] = 'n';
					 break;
				case 'O':
					 s[i] = 'o';
					 break;
				case 'P':
					 s[i] = 'p';
					 break;
				case 'Q':
					 s[i] = 'q';
					 break;
				case 'R':
					 s[i] = 'r';
					 break;
				case 'S':
					 s[i] = 's';
					 break;
				case 'T':
					 s[i] = 't';	
					 break;
				case 'U':
					 s[i] = 'u';
					 break;
				case 'V':
					 s[i] = 'v';
					 break;
				case 'W': 
					 s[i] = 'w';
					 break;
				case 'X':
					 s[i] = 'x';
					 break;
				case 'Y':
					 s[i] = 'y';
					 break;
				case 'Z':
					 s[i] = 'z';
					 break;
			}	
		}
	 	search(s);
		printf("\n\n");
	}
}

void search(char *s){
	int len, fd, i, j, cnt, k, l, flag, chk;
	flag = 0;
	len = strlen(s);	
	char c[10000], ch, d[100], n[3], f[10];
	f[0] = s[0];
	int ind = 2;
	switch(len){
		case 2:
			f[1] = '2'; 
			break;
		case 3:
			f[1] = '3'; 
			break;
		case 4:
			f[1] = '4'; 
			break;
		case 5:
			f[1] = '5'; 
			break;
		case 6:
			f[1] = '6'; 
			break;
		case 7:
			f[1] = '7'; 
			break;
		case 8:
			f[1] = '8'; 
			break;
		case 9:			
	 		f[1] = '9';
			break;
		case 10:
			f[1] = '1';
			f[2] = '0';
			ind = 3;
			break;
		case 11:
			f[1] = '1';
			f[2] = '1';
			ind = 3;
			break;
		case 12:
			f[1] = '1';
			f[2] = '2';
			ind = 3;
			break;
		case 13:
			f[1] = '1';
			f[2] = '3';
			ind = 3;
			break;
		case 14:
			f[1] = '1';
			f[2] = '4';
			ind = 3;
			break;
		case 15:
			f[1] = '1';
			f[2] = '5';
			ind = 3;
			break;
		default:
			ind = 1;
			break;
	}
	f[ind] = '.';
	f[ind + 1] = 't';
	f[ind + 2] = 'x';
	f[ind + 3] = 't';
	f[ind + 4] = '\0';
	fd = open(f, O_RDONLY);
	if(fd == -1){
		printf("Fail to open dictionary source file\n");
		exit(-1);	
	}
	else{
		while(read(fd, &ch, 1) != 0){
			cnt = 0;
			c[cnt++] = ch;
			while(read(fd, &ch, 1) != 0 && ch != '\n'){
				c[cnt++] = ch;
				c[cnt] = '\0';
			}
			if(c[0] == s[0]){
				for(i = 0; i < len; i++)
					d[i] = c[i];
				if(strcmp(d, s) == 0){
					if(c[len] = '|'){
						for(j = len + 1, k = 0; c[j] != '\0'; j++, k++)
							n[k] = c[j];
					l = atoi(n);
					flag = l;
					break;
				}
			}
		}
	}
		
}
	if(flag != 0){
		for(i = 0; i < l; i++){
			while(read(fd, &ch, 1) != 0 && ch != '\n')
 				printf("%c", ch);
 			printf("\n");
		}
	}
	else if(flag == 0)
		suggest(s);
}

void suggest(char *s){
	int len, fd, i, j, cnt, k, l, flag, chk;
	printf("word not found\n");
	char c[10000], ch, d[100], n[3], f[10];
	f[0] = s[0];
	len =strlen(s);
	int ind = 2;
	switch(len){
		case 2:
			f[1] = '2'; 
			break;
		case 3:
			f[1] = '3'; 
			break;
		case 4:
			f[1] = '4'; 
			break;
		case 5:
			f[1] = '5'; 
			break;
		case 6:
			f[1] = '6'; 
			break;
		case 7:
			f[1] = '7'; 
			break;
		case 8:
			f[1] = '8'; 
			break;
		case 9:			
	 		f[1] = '9';
			break;
		case 10:
			f[1] = '1';
			f[2] = '0';
			ind = 3;
			break;
		case 11:
			f[1] = '1';
			f[2] = '1';
			ind = 3;
			break;
		case 12:
			f[1] = '1';
			f[2] = '2';
			ind = 3;
			break;
		case 13:
			f[1] = '1';
			f[2] = '3';
			ind = 3;
			break;
		case 14:
			f[1] = '1';
			f[2] = '4';
			ind = 3;
			break;
		case 15:
			f[1] = '1';
			f[2] = '5';
			ind = 3;
			break;
		default:
			ind = 1;
			break;
	}
	f[ind] = '.';
	f[ind + 1] = 't';
	f[ind + 2] = 'x';
	f[ind + 3] = 't';
	fd = open(f, O_RDONLY);
	if(fd == -1){
		printf("Fail to open dictionary source file\n");
		exit(-1);	
	}
	else{
		chk = 0;
		while(read(fd, &ch, 1) != 0){	
			cnt = 0;
			l = 0;
			c[cnt++] = ch;
			while(read(fd, &ch, 1) != 0 && ch != '\n')
				c[cnt++] = ch;
			c[cnt] = '\0';
			if(c[0] == s[0]){
				for(j = 0; j < len ; j++)
					d[j] = c[j];
				d[j] = '\0';
				for(k = 0; k < len ; k++)
					if(d[k] == s[k])
						l++;
				if(l == len - 1){
					chk++;
					if(chk == 1)
						printf("Do you mean:\n");
					printf("\t %s\n", d);
					}
				}
			}
	}
}
